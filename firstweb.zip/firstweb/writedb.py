#writedb.py

import sqlite3
